"""PySerial transport implementation used by the native bridge."""

from ._native_library import (
    _PySerialTransport,
    _crc16,
    _serial_available_bytes,
    _serial_receive_byte,
    _serial_time_ms,
    _serial_transmit,
    _transport_from_context,
)

__all__ = [
    "_PySerialTransport", "_crc16", "_serial_available_bytes",
    "_serial_receive_byte", "_serial_time_ms", "_serial_transmit",
    "_transport_from_context",
]
